function openGame(url) {
    window.open(url, '_blank');
  }